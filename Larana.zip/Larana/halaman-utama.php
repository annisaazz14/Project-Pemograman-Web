<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Baby Shop - Beranda</title>
    <link rel="stylesheet" href="asset/halaman-utama.css">
</head>
<body>

<div class="wrapper">

    <!-- Navbar -->
    <nav class="navbar">
        <a href="halaman-utama.php">Home</a>
        <a href="produk.php">Produk</a>
        <a href="keranjang.php">Keranjang</a>
        <a href="auth/logout.php">Logout</a>
        <?php if (!isset($_SESSION['username'])): ?>
            <a href="auth/login.php">Login</a>
        <?php endif; ?>
    </nav>

    <!-- Slider -->
    <div class="slider">
    <img src="asset/images/slider2.jpg" alt="Slide 2">
    <img src="asset/images/slider3.jpg" alt="Slide 3">
    <div class="hero-overlay">
        <h1>Selamat Datang di Larana Baby Care</h1>
        <p>Toko perlengkapan bayi terlengkap dan terpercaya</p>
        <a href="produk.php">
            <button class="cta-btn">Lihat Produk</button>
        </a>
    </div>
</div>

    <!-- Fitur Unggulan -->
    <section class="features">
        <div class="feature">
            <h3>Produk Aman</h3>
            <p>Semua produk telah lulus uji keamanan untuk bayi.</p>
        </div>
        <div class="feature">
            <h3>Pengiriman Cepat</h3>
            <p>Barang sampai di tangan Anda dalam 1-2 hari.</p>
        </div>
        <div class="feature">
            <h3>Harga Terbaik</h3>
            <p>Dapatkan harga terjangkau dengan kualitas terbaik.</p>
        </div>
    </section>

    <!-- Gambar Tambahan -->
    <section class="image-gallery">
        <h2>Produk Unggulan Kami</h2>
        <div class="gallery">
            <img src="asset/images/baby1.jpg" alt="Produk 1">
            <img src="asset/images/baby4.jpg" alt="Produk 2">
            <img src="asset/images/baby3.jpg" alt="Produk 3">
        </div>
    </section>

    <!-- Testimoni -->
    <section class="testimonials">
        <h2>Apa Kata Mereka</h2>
        <div class="testimonial-cards">
            <div class="card">
                <p>"Barangnya lucu dan berkualitas! Anak saya suka banget."</p>
                <strong>- Ibu Rina</strong>
            </div>
            <div class="card">
                <p>"Pelayanan cepat dan ramah. Suka belanja di sini!"</p>
                <strong>- Bunda Tika</strong>
            </div>
            <div class="card">
                <p>"Harga bersaing dan produknya aman untuk bayi saya."</p>
                <strong>- Ayah Dimas</strong>
            </div>
        </div>
    </section>

    <!-- CTA Bawah -->
    <section class="cta-bottom">
        <h2>Siap belanja untuk si kecil?</h2>
        <a href="produk.php">
            <button class="cta-btn">Mulai Belanja Sekarang</button>
        </a>
    </section>

</div>

<!-- Footer -->
<footer>
    <div class="footer-content">
        <p>&copy; <?= date('Y') ?> Larana Baby Care. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Tentang Kami</a>
            <a href="#">Kontak</a>
            <a href="#">Kebijakan Privasi</a>
        </div>
    </div>
</footer>

</body>
</html>
