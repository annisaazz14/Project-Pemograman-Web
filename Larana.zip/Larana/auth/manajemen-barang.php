<?php
// manajemen-barang.php - Auto-generated template
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Barang</title>
    <link rel='stylesheet' href='/assets/css/style.css'>
</head>
<body>
    <h1>Manajemen Barang</h1>
</body>
</html>