<?php
// manajemen-stok.php - Auto-generated template
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Stok</title>
    <link rel='stylesheet' href='/assets/css/style.css'>
</head>
<body>
    <h1>Manajemen Stok</h1>
</body>
</html>