<?php
// dashboard.php - Auto-generated template
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel='stylesheet' href='/assets/css/style.css'>
</head>
<body>
    <h1>Dashboard</h1>
</body>
</html>