<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "baby_shop";

// Create connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check connection
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
