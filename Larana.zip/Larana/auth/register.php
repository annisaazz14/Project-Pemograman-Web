<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $konfirmasi = trim($_POST['konfirmasi']);

    // Validasi konfirmasi password
    if ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak cocok!";
    } else {
        // Cek apakah username sudah digunakan
        $check = mysqli_query($conn, "SELECT * FROM pengguna WHERE username='$username'");
        if (mysqli_num_rows($check) > 0) {
            $error = "Username sudah terdaftar!";
        } else {
            // Simpan user baru (pakai password_hash lebih aman)
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO pengguna (username, password, role) VALUES ('$username', '$hashed', 'user')";
            if (mysqli_query($conn, $query)) {
                echo "<script>alert('Registrasi berhasil! Silakan login.');window.location='login.php';</script>";
                exit;
            } else {
                $error = "Terjadi kesalahan saat menyimpan data!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register - Baby Shop</title>
    <link rel="stylesheet" href="../asset/register.css">
</head>
<body>

<div class="register-container">
    <h2>Register</h2>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="post">
        <label>Username:</label>
        <input type="text" name="username" required><br>

        <label>Password:</label>
        <input type="password" name="password" required><br>

        <label>Konfirmasi Password:</label>
        <input type="password" name="konfirmasi" required><br>

        <button type="submit" name="submit">Register</button>
    </form>

    <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
</div>

</body>
</html>
