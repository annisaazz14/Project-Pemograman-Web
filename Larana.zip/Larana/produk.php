<?php
session_start();
include 'auth/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit;
}

// Ambil semua produk dari database
$produk = mysqli_query($conn, "SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Produk</title>
    <link rel="stylesheet" href="asset/produk.css">
</head>
<body>

<!-- Navbar -->
<nav>
    <a href="halaman-utama.php">Home</a>
    <a href="produk.php">Produk</a>
    <a href="keranjang.php">Keranjang</a>
    <a href="auth/logout.php">Logout</a>
</nav>

<!-- Daftar Produk -->
<div class="container">
    <h1>Produk Kami</h1>

    <div class="produk-list">
        <?php while ($row = mysqli_fetch_assoc($produk)): ?>
            <div class="produk-item">
                <img src="asset/images/<?= htmlspecialchars($row['gambar']) ?>" alt="<?= htmlspecialchars($row['nama_produk']) ?>">
                <h3><?= htmlspecialchars($row['nama_produk']) ?></h3>
                <p><?= htmlspecialchars($row['deskripsi']) ?></p>
                <p><strong>Rp<?= number_format($row['harga'], 0, ',', '.') ?></strong></p>
                <a href="keranjang.php?add=<?= $row['id'] ?>"><button>Tambah ke Keranjang</button></a>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
