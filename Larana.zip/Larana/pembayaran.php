<?php
session_start();
include 'auth/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit;
}

// Ambil data user login
$username = $_SESSION['username'];
$query = mysqli_query($conn, "SELECT * FROM pengguna WHERE username = '$username'");
$user = mysqli_fetch_assoc($query);
$user_id = $user['id'];

// Ambil total dari keranjang berdasarkan user_id
$query_total = mysqli_query($conn, "SELECT SUM(jumlah * harga) AS total FROM keranjang WHERE user_id = '$user_id'");
$data_total = mysqli_fetch_assoc($query_total);
$total = $data_total['total'] ?? 0;

// Proses submit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $metode = $_POST['metode'];
    $nama_penerima = $_POST['nama_penerima'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];
    $bank = $_POST['bank'] ?? null;
    $bukti = '';

    // Upload bukti jika metode transfer
    if ($metode === 'Transfer Bank' && isset($_FILES['bukti_transfer'])) {
        $file = $_FILES['bukti_transfer'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $namaFileBaru = uniqid() . '.' . $ext;
        $pathUpload = 'uploads/' . $namaFileBaru;

        if (move_uploaded_file($file['tmp_name'], $pathUpload)) {
            $bukti = $namaFileBaru;
        }
    }

    $sql = "INSERT INTO pembayaran (user_id, total, metode, status, nama_penerima, alamat, no_telepon, bank, bukti_transfer)
            VALUES ('$user_id', '$total', '$metode', 'belum dibayar', '$nama_penerima', '$alamat', '$no_telepon', '$bank', '$bukti')";

    if (mysqli_query($conn, $sql)) {
        // Hapus isi keranjang setelah pembayaran berhasil
        mysqli_query($conn, "DELETE FROM keranjang WHERE user_id = '$user_id'");

        echo "<script>alert('Pembayaran berhasil disimpan!');window.location='halaman-utama.php';</script>";
    } else {
        echo "Gagal menyimpan pembayaran: " . mysqli_error($conn);
    }

    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Pembayaran</title>
    <link rel="stylesheet" href="asset/pembayaran.css">
</head>
<body>
<h1>Form Pembayaran</h1>

<form action="" method="post" enctype="multipart/form-data">

    <label>Nama Penerima:</label><br>
    <input type="text" name="nama_penerima" required><br><br>

    <label>Alamat:</label><br>
    <textarea name="alamat" required></textarea><br><br>

    <label>No Telepon:</label><br>
    <input type="text" name="no_telepon" required><br><br>

    <label>Metode Pembayaran:</label><br>
    <select name="metode" id="metode" required onchange="toggleTransferFields()">
        <option value="COD">COD</option>
        <option value="Transfer Bank">Transfer Bank</option>
    </select><br><br>

    <div id="transferFields" style="display:none;">
        <label>Bank Tujuan:</label><br>
        <select name="bank">
            <option value="BCA">BCA - 1234567890</option>
            <option value="BNI">BNI - 9876543210</option>
            <option value="Mandiri">Mandiri - 5678901234</option>
        </select><br><br>

        <label>Bukti Transfer:</label><br>
        <input type="file" name="bukti_transfer" accept="image/*"><br><br>
    </div>

    <button type="submit" name="submit">Bayar</button>
</form>

<script>
function toggleTransferFields() {
    var metode = document.getElementById("metode").value;
    var transferFields = document.getElementById("transferFields");
    transferFields.style.display = metode === "Transfer Bank" ? "block" : "none";
}
window.onload = toggleTransferFields;
</script>

</body>
</html>
