<?php
session_start();
include 'auth/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_pengirim'];
    $metode = $_POST['metode'];
    $total = $_POST['total'];
    $id_user = $_SESSION['id'];

    // Upload bukti jika transfer
    $nama_file = '';
    if ($metode == 'transfer' && isset($_FILES['bukti']['tmp_name'])) {
        $file = $_FILES['bukti'];
        $nama_file = time() . '_' . basename($file['name']);
        move_uploaded_file($file['tmp_name'], 'uploads/' . $nama_file);
    }

    // Simpan ke tabel pembayaran
    $stmt = $conn->prepare("INSERT INTO pembayaran (id_user, nama_pengirim, metode, total, bukti, status) VALUES (?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("issis", $id_user, $nama, $metode, $total, $nama_file);
    if (!$stmt->execute()) {
        die("Gagal simpan pembayaran: " . $stmt->error);
    }
    $id_pembayaran = $conn->insert_id;

    // Ambil isi keranjang
    $keranjang = $_SESSION['keranjang'] ?? [];

    if (!empty($keranjang)) {
        // Ambil data produk
        $produkList = [];
        $result = $conn->query("SELECT id, harga FROM produk");
        while ($row = $result->fetch_assoc()) {
            $produkList[$row['id']] = $row['harga'];
        }

        // Hitung total barang
        $total_barang = array_sum($keranjang);

        // Simpan ke tabel pesanan
        $stmt2 = $conn->prepare("INSERT INTO pesanan (pengguna_id, id_pembayaran, total_barang, total_harga) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("iiii", $id_user, $id_pembayaran, $total_barang, $total);
        if (!$stmt2->execute()) {
            die("Gagal simpan pesanan: " . $stmt2->error);
        }
        $pesanan_id = $conn->insert_id;

        // Simpan ke detail_pesanan
        $stmt3 = $conn->prepare("INSERT INTO detail_pesanan (pesanan_id, produk_id, jumlah, harga_satuan) VALUES (?, ?, ?, ?)");
        foreach ($keranjang as $produk_id => $jumlah) {
            $harga = $produkList[$produk_id] ?? 0;
            $stmt3->bind_param("iiii", $pesanan_id, $produk_id, $jumlah, $harga);
            if (!$stmt3->execute()) {
                echo "Gagal simpan detail produk ID $produk_id: " . $stmt3->error . "<br>";
            }
        }
    }

    // Kosongkan keranjang
    unset($_SESSION['keranjang']);

    echo "<script>alert('Pembayaran dan pesanan berhasil! Menunggu konfirmasi.');window.location='halaman-utama.php';</script>";
}
?>
