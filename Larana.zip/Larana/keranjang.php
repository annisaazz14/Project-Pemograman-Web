<?php
session_start();
include 'auth/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit;
}

// Ambil semua produk dari database untuk referensi ID dan harga
$produk = [];
$result = mysqli_query($conn, "SELECT id, nama_produk, harga FROM produk");
while ($row = mysqli_fetch_assoc($result)) {
    $produk[$row['id']] = [
        'nama' => $row['nama_produk'],
        'harga' => $row['harga']
    ];
}

// Tambah ke keranjang
if (isset($_GET['add'])) {
    $id = (int)$_GET['add'];
    if (isset($produk[$id])) {
        $_SESSION['keranjang'][$id] = ($_SESSION['keranjang'][$id] ?? 0) + 1;
    }
    header("Location: keranjang.php");
    exit;
}

// Hapus dari keranjang
if (isset($_GET['remove'])) {
    $id = (int)$_GET['remove'];
    unset($_SESSION['keranjang'][$id]);
    header("Location: keranjang.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="asset/keranjang.css">
</head>
<body>

<!-- Navbar -->
<nav>
    <a href="halaman-utama.php">Home</a>
    <a href="produk.php">Produk</a>
    <a href="keranjang.php">Keranjang</a>
    <a href="auth/logout.php">Logout</a>
</nav>

<div class="container">
    <h1>Keranjang Belanja Anda</h1>

    <?php if (!empty($_SESSION['keranjang'])): ?>
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach ($_SESSION['keranjang'] as $id => $qty):
                    if (!isset($produk[$id])) continue; // skip jika produk tidak ditemukan
                    $nama = $produk[$id]['nama'];
                    $harga = $produk[$id]['harga'];
                    $subtotal = $harga * $qty;
                    $total += $subtotal;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($nama) ?></td>
                        <td><?= $qty ?></td>
                        <td>Rp<?= number_format($harga, 0, ',', '.') ?></td>
                        <td>Rp<?= number_format($subtotal, 0, ',', '.') ?></td>
                        <td><a href="?remove=<?= $id ?>">Hapus</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p><strong>Total: Rp<?= number_format($total, 0, ',', '.') ?></strong></p>

        <!-- Tombol Checkout -->
        <div>
            <form action="pembayaran.php" method="get" style="display: inline;">
                <input type="hidden" name="total" value="<?= $total ?>">
                <button type="submit">Lanjut ke Pembayaran</button>
            </form>
            <a href="produk.php"><button type="button">Lihat Produk Lagi</button></a>
        </div>
    <?php else: ?>
        <div class="empty-cart">
            🛒 Keranjang kosong. Yuk belanja di <a href="produk.php">halaman produk</a>!
        </div>
    <?php endif; ?>
</div>

</body>
</html>
